#include <stdio.h>

void printnl() {

    printf("\n");

}
