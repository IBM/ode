// $Id: lpginput.cpp,v 1.6 2000/07/25 11:32:33 mdejong Exp $
//
// This software is subject to the terms of the IBM Jikes Compiler
// License Agreement available at the following URL:
// http://www.ibm.com/research/jikes.
// Copyright (C) 1996, 1998, International Business Machines Corporation
// and others.  All Rights Reserved.
// You must accept the terms of that agreement to use this software.
//

#include "lpginput.h"
#include "javadcl.h"

#ifdef	HAVE_NAMESPACES
using namespace Jikes;
#endif
