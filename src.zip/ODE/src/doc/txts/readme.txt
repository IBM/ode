********************************************************************************
*** INSTALLATION ***

This is release %RELEASE_NAME% of ODE.  Refer to Administrator's guide for
installation instructions
  http://w3.ode.raleigh.ibm.com/%RELEASE_NUM%/doc/pubs/ODEAdminsGuide.htm
Available from:
  http://w3.ode.raleigh.ibm.com/%RELEASE_NUM%/doc/pubs/index.htm

********************************************************************************
*** NOTES ***

********************************************************************************
*** KNOWN PROBLEMS/LIMITATIONS ***

See %release_name%_b%LEVEL_NAME%_known_bugs.txt for known limitations and bugs.

********************************************************************************
*** FIXES ***

See %release_name%_b%LEVEL_NAME%_fixes.txt for a list of fixes per build.

********************************************************************************
*** LICENSE ***

See ODELicense_ILA.txt and ODELicense_3rdParty.txt for ODE licensing
information.

********************************************************************************
*** EOF ***

