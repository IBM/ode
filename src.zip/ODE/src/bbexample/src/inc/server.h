#ifndef _SERVER_H_
#define _SERVER_H_

#define DEFAULTMSG "Example for simple ODE backing build."

#endif /* _SERVER_H_ */
