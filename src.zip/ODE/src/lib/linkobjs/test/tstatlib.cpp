/**
 * This program is linked statically with the C library, so it
 * should crash whereas the one linked dynamically should not.
 *
**/

#include "tshlib.cpp" // same code, just linked differently
