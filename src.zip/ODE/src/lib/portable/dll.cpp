#ifdef __cplusplus
extern "C" {
#endif

extern int _dllentry;
static int *ODELIB_DLL_entry = &_dllentry;

#ifdef __cplusplus
}
#endif
